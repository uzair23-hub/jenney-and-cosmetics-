<footer class="bg-dark text-center text-white p-3 mt-4">
    &copy; <?= date("Y"); ?> Janny's Store | Admin Panel
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
