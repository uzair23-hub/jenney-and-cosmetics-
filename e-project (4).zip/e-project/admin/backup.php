<?php
session_start();
include("../includes/db.php");

// Restrict access to admin only
if (!isset($_SESSION['admin_id'])) {
    header("Location: login.php");
    exit();
}

// Backup process
if (isset($_POST['backup'])) {
    $database = "ecommerce_db"; // Change to your database name
    $user = "root"; // Change to your DB username
    $password = ""; // Change if you have a DB password
    $host = "localhost";
    $backupFile = "../backups/db_backup_" . date("Y-m-d_H-i-s") . ".sql";

    // Create backups folder if not exists
    if (!file_exists("../backups")) {
        mkdir("../backups", 0777, true);
    }

    // Command to execute MySQL dump
    $command = "mysqldump --host=$host --user=$user --password=$password $database > $backupFile";

    // Execute the command
    system($command, $output);

    if ($output === 0) {
        $message = "✅ Database backup created successfully! <br> <a href='$backupFile' class='btn btn-success mt-3' download>Download Backup</a>";
    } else {
        $message = "❌ Failed to create database backup!";
    }
}
?>

<?php include("includes/admin_header.php"); ?>

<div class="container my-5">
    <div class="card shadow-lg border-0 rounded-3">
        <div class="card-header bg-dark text-white">
            <h4 class="mb-0"><i class="bi bi-hdd"></i> Database Backup</h4>
        </div>
        <div class="card-body text-center">
            <p class="lead text-muted">Click the button below to generate a complete database backup.</p>
            <form method="post">
                <button type="submit" name="backup" class="btn btn-primary px-4 py-2">
                    <i class="bi bi-download"></i> Create Backup
                </button>
            </form>
            <?php if (!empty($message)) : ?>
                <div class="alert alert-info mt-4"><?= $message ?></div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php include("includes/admin_footer.php"); ?>
