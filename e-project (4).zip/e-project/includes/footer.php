<!-- Footer -->
<footer class="text-center text-white mt-5" style="background-color:#473068;">
  <div class="container py-4">
    <h5 class="fw-bold">Jenny's Cosmetics & Jewelry</h5>
    <p>Premium cosmetics and imitation jewelry delivered to your doorstep</p>
    
    <!-- Social Icons -->
    <div class="mb-3">
      <a href="#" class="text-white me-3 fs-5"><i class="bi bi-facebook"></i></a>
      <a href="#" class="text-white me-3 fs-5"><i class="bi bi-instagram"></i></a>
      <a href="#" class="text-white me-3 fs-5"><i class="bi bi-twitter"></i></a>
      <a href="#" class="text-white fs-5"><i class="bi bi-whatsapp"></i></a>
    </div>

    <p class="mb-0">&copy; <?= date("Y"); ?> Jenny's Store. All Rights Reserved.</p>
  </div>
</footer>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="assets/js/script.js"></script>
</body>
</html>
