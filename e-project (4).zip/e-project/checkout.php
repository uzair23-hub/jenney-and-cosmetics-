<?php
include("includes/header.php");
include("includes/db.php");

// Start session
if (!isset($_SESSION)) {
    session_start();
}

// If cart is empty, redirect to products page
if (empty($_SESSION['cart'])) {
    echo "<script>alert('Your cart is empty!'); window.location='products.php';</script>";
    exit();
}

// Handle Order Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name       = mysqli_real_escape_string($conn, $_POST['name']);
    $email      = mysqli_real_escape_string($conn, $_POST['email']);
    $address    = mysqli_real_escape_string($conn, $_POST['address']);
    $work_phone = mysqli_real_escape_string($conn, $_POST['work_phone']);
    $cell_phone = mysqli_real_escape_string($conn, $_POST['cell_phone']);
    $dob        = mysqli_real_escape_string($conn, $_POST['dob']);
    $category= mysqli_real_escape_string($conn, $_POST['category']);
    $remarks    = mysqli_real_escape_string($conn, $_POST['remarks']);

    // Insert customer info
    $customer_query = "INSERT INTO customers (name, address, email, work_phone, cell_phone, dob, category, remarks) 
                       VALUES ('$name', '$address', '$email', '$work_phone', '$cell_phone', '$dob','$category', '$remarks')";
    mysqli_query($conn, $customer_query);

    $customer_id = mysqli_insert_id($conn);

    // Insert order info
    $order_query = "INSERT INTO orders (customer_id) VALUES ('$customer_id')";
    mysqli_query($conn, $order_query);

    $order_id = mysqli_insert_id($conn);

    // Insert order items
    foreach ($_SESSION['cart'] as $product_id => $quantity) {
        $order_items_query = "INSERT INTO order_items (order_id, product_id, quantity) 
                              VALUES ('$order_id', '$product_id', '$quantity')";
        mysqli_query($conn, $order_items_query);

        // Update stock
        mysqli_query($conn, "UPDATE products SET stock = stock - $quantity WHERE id = '$product_id'");
    }

    // Clear cart
    unset($_SESSION['cart']);

    // Redirect to thank you page
    echo "<script>alert('Your order has been placed successfully!'); window.location='thankyou.php?order_id=$order_id';</script>";
    exit();
}
?>

<div class="container my-5">
    <h2 class="fw-bold mb-4">Checkout</h2>
    <div class="row">
        <!-- Customer Information -->
        <div class="col-md-7">
            <div class="card shadow p-4">
                <h5 class="fw-bold mb-3">Billing Details</h5>
                <form method="POST" action="checkout.php">
                    <div class="mb-3">
                        <label class="form-label fw-bold">Full Name</label>
                        <input type="text" name="name" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Email</label>
                        <input type="email" name="email" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Address</label>
                        <textarea name="address" class="form-control" rows="2" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Work Phone</label>
                            <input type="text" name="work_phone" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label fw-bold">Cell Phone</label>
                            <input type="text" name="cell_phone" class="form-control" required>
                        </div>
                    </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Date of Birth</label>
                        <input type="date" name="dob" class="form-control">
                    </div>

                     <div class="mb-3">
                            <label class="form-label fw-bold">Category</label>
                            
                            <select name="category" >
            <option value="regular">Regular</option>
            <option value="vip">VIP</option>

           </select>
                        </div>
                    <div class="mb-3">
                        <label class="form-label fw-bold">Remarks</label>
                        <textarea name="remarks" class="form-control" rows="2"></textarea>
                    </div>
                    <button type="submit" class="btn btn-buy w-100">Place Order</button>
                </form>
            </div>
        </div>

        <!-- Order Summary -->
        <div class="col-md-5">
            <div class="card shadow p-4">
                <h5 class="fw-bold mb-3">Your Order</h5>
                <ul class="list-group list-group-flush mb-3">
                    <?php
                    $total = 0;
                    foreach ($_SESSION['cart'] as $product_id => $quantity) {
                        $query = "SELECT * FROM products WHERE id = '$product_id'";
                        $result = mysqli_query($conn, $query);
                        $product = mysqli_fetch_assoc($result);

                        $subtotal = $product['price'] * $quantity;
                        $total += $subtotal;
                    ?>
                        <li class="list-group-item d-flex justify-content-between align-items-center">
                            <?= $product['name']; ?> <span class="badge bg-secondary"><?= $quantity; ?> x <?= number_format($product['price']); ?></span>
                        </li>
                    <?php } ?>
                </ul>
                <h5 class="text-end fw-bold">Total: PKR <?php echo number_format($total); ?></h5>
            </div>
        </div>
    </div>
</div>

<?php include("includes/footer.php"); ?>
