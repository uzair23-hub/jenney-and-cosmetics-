<?php
// About Us Page - Jenny Cosmetics & Jewellery
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Us - Jenny Cosmetics & Jewellery</title>
  <style>
    /* body {
      margin: 0;
      padding: 0;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      color: #2f2f2f;

      background: linear-gradient(rgba(230, 230, 250, 0.9), rgba(230, 230, 250, 0.9)),
                  url('images/jewellery-bg.jpg') no-repeat center center/cover;
    } */

    #container {
      max-width: 900px;
      margin: auto;
      background: rgba(255, 255, 255, 0.92);
      padding: 50px;
      border-radius: 20px;
      box-shadow: 0 8px 25px rgba(0,0,0,0.2);
      margin-top: 70px;
      margin-bottom: 70px;
      animation: fadeIn 1.2s ease-in-out;
    }

    #hed {
      color: #6a0dad; /* Purple */
      font-size: 2.8rem;
      margin-bottom: 25px;
      text-align: center;
      letter-spacing: 2px;
      font-weight: 800;
    }

    #hed::after {
      content: "";
      display: block;
      width: 100px;
      height: 4px;
      background: #6a0dad;
      margin: 14px auto;
      border-radius: 3px;
    }

  .para {
      font-size: 1.2rem;
      margin-bottom: 22px;
      line-height: 1.9;
      text-align: justify;
    }

    .highlight {
      color: #6a0dad;
      font-weight: bold;
    }

    @keyframes fadeIn {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  </style>
</head>
<body>
    <?php include("includes/header.php");
include("includes/db.php");?>
  <div id="container">
    <h1 id="hed">About Us</h1>
    <p class="para">
      Welcome to <span class="highlight">Jenny Cosmetics & Jewellery</span>,  
      your trusted home for <strong>luxury beauty</strong> and <strong>timeless elegance</strong>.
    </p>
    <p class="para">
      At Jenny, we believe every woman deserves to shine — whether it’s through  
      the <span class="highlight">radiance of flawless cosmetics</span> or the  
      <span class="highlight">sparkle of exquisite jewellery</span>.
    </p>
    <p class="para">
      Our collection blends <strong>modern trends</strong> with <strong>classic designs</strong>,  
      offering everything from <strong>premium skincare and makeup</strong> to  
      <strong>handcrafted bridal sets, everyday wear, and statement jewellery</strong>.
    </p>
    <p class="para">
      With <span class="highlight">quality, trust, and sophistication</span> at our core,  
      Jenny Cosmetics & Jewellery is more than just a brand — it’s a lifestyle  
      where <span class="highlight">glamour meets confidence</span>.
    </p>
    <p class="para">
      Thank you for making us part of your journey to beauty and elegance.  
    </p>
  </div>
</body>
</html>
<?php include("includes/footer.php"); ?>