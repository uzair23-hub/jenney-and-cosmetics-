<?php include("includes/header.php"); ?>

<!-- Hero Section -->
<section class="hero">
  <div class="container text-center text-white">
    <h1 class="fw-bold">Welcome to Jenny's Cosmetics & Jewelry</h1>
    <p>Discover premium cosmetics & imitation jewelry at unbeatable prices!</p>
    <a href="products.php" class="btn btn-shop">Shop Now</a>
  </div>
</section>

<!-- Categories Section -->
<section class="categories py-5">
  <div class="container">
    <h2 class="text-center mb-4">Shop by Categories</h2>
    <div class="row g-4">
      <div class="col-md-3">
        <div class="category-card">
          <img src="./photos/makeup.jpg" alt="Makeup" />
          <h5>Makeup</h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="category-card">
          <img src="./photos/skincare.jpg" alt="Skincare" />
          <h5>Skincare</h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="category-card">
          <img src="./photos/jewelary.jpg" alt="Jewelry" />
          <h5>Jewelry</h5>
        </div>
      </div>
      <div class="col-md-3">
        <div class="category-card">
          <img src="./photos/perfume.jpg" alt="Perfume" />
          <h5>Perfumes</h5>
        </div>
      </div>
    </div>
  </div>
</section>

<!-- Featured Products -->
<section class="featured-products py-5">
  <div class="container">
    <h2 class="text-center mb-4">Featured Products</h2>
    <div class="row g-4">
      <!-- Product Card -->
      <div class="col-md-3">
        <div class="product-card">
          <img src="./photos/makeup.jpg" alt="Lipstick">
          <h5>Matte Lipstick</h5>
          <p class="price">PKR 950</p>
          <a href="product_detail.php?id=1" class="btn btn-buy">View Details</a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="product-card">
          <img src="./photos/skincare.jpg" alt="Foundation">
          <h5>Flawless Foundation</h5>
          <p class="price">PKR 2,200</p>
          <a href="product_detail.php?id=2" class="btn btn-buy">View Details</a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="product-card">
          <img src="./photos/jewelary.jpg" alt="Rings">
          <h5>Gold Plated Rings</h5>
          <p class="price">PKR 1,750</p>
          <a href="product_detail.php?id=3" class="btn btn-buy">View Details</a>
        </div>
      </div>
      <div class="col-md-3">
        <div class="product-card">
          <img src="./photos/perfume.jpg" alt="Earrings">
          <h5>Diamond Earrings</h5>
          <p class="price">PKR 3,000</p>
          <a href="product_detail.php?id=4" class="btn btn-buy">View Details</a>
        </div>
      </div>
    </div>
  </div>
</section>

<?php include("includes/footer.php"); ?>
